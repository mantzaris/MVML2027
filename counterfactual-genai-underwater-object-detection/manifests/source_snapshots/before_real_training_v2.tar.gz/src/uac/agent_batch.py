"""Batched bounded generation; preserve individual traces and honest timing units."""
import json,time
from uac.agent import validate_state,parse_action,SYSTEM_PROMPT,MODEL_ID
from uac.runtime import fingerprint


def select_actions(controller,states):
    torch=controller.torch
    cleaned=[validate_state(state) for state in states]
    if any(s['remaining_actions']<=0 for s in cleaned):raise ValueError('Only active states may enter batched generation')
    texts=[]
    for state in cleaned:
        messages=[{'role':'system','content':SYSTEM_PROMPT},{'role':'user','content':json.dumps(state,sort_keys=True,separators=(',',':'))}]
        texts.append(controller.tokenizer.apply_chat_template(messages,tokenize=False,add_generation_prompt=True))
    controller.tokenizer.padding_side='left'
    if controller.tokenizer.pad_token_id is None:controller.tokenizer.pad_token=controller.tokenizer.eos_token
    started=time.perf_counter()
    encoded=controller.tokenizer(texts,padding=True,return_tensors='pt',add_special_tokens=False)
    lengths=encoded['attention_mask'].sum(-1).tolist()
    if max(lengths)+controller.max_output_tokens>controller.max_context_tokens:raise ValueError('Batched context budget exceeded; no truncation')
    encoded={key:value.to('cuda') for key,value in encoded.items()}
    torch.cuda.synchronize();event_start=torch.cuda.Event(enable_timing=True);event_end=torch.cuda.Event(enable_timing=True);event_start.record()
    with torch.inference_mode():
        generated=controller.model.generate(**encoded,max_new_tokens=controller.max_output_tokens,do_sample=False,use_cache=True,pad_token_id=controller.tokenizer.pad_token_id)
    event_end.record();torch.cuda.synchronize();wall=time.perf_counter()-started;gpu_ms=event_start.elapsed_time(event_end)
    result=[]
    for i,state in enumerate(cleaned):
        tokens=generated[i,encoded['input_ids'].shape[1]:]
        eos=(tokens==controller.tokenizer.eos_token_id).nonzero().flatten()
        count=int(eos[0])+1 if len(eos) else len(tokens)
        raw=controller.tokenizer.decode(tokens[:count],skip_special_tokens=True)
        result.append({**parse_action(raw,state),'raw_text':raw,'model':MODEL_ID,'revision':controller.revision,'prompt_sha256':controller.prompt_sha256,'state_sha256':fingerprint(state),'input_tokens':int(lengths[i]),'output_tokens':count,'batch_size':len(states),'batch_wall_seconds':wall,'batch_cuda_ms':float(gpu_ms),'amortized_seconds':wall/len(states),'latency_seconds':wall,'measurement_mode':'live_batched_model_call','peak_allocated_mib':torch.cuda.max_memory_allocated()/1024**2})
    return result
