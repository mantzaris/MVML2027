# Execution decisions before model evaluation

Recorded 23 November 2026. These decisions adapt the prospective plan to actual data access and numerical checks. No real-data model predictions or final test results had been produced when these choices were made.

## Data source

The requested UniqueShip public archives returned download-quota pages. The study instead uses the public PORTIA v2 release from Valencia: https://zenodo.org/records/21409381, with AIS-associated vessel-presence labels. This is a geographically and temporally different collection from the sibling submission's ONC data.

The primary cohort combines single-vessel task positives and binary-task backgrounds, excluding every window with conflicting cross-task labels. The metadata audit found 2,388 conflicting window IDs; neither copy is used. It is a custom cohort, not a reproduction of the official PORTIA split. Day assignment uses a predetermined seed17 hash allocation, followed by purging vessel identities across partitions, prioritizing test, calibration, development, then training. Selection and class/source caps use metadata only, before audio-model outcomes.

Final selected counts are 3,735 training clips, 735 development, 600 calibration and 1,200 locked test clips. Vessel identities and UTC days are disjoint across partitions. The test set includes42 vessel identities and five days; the effective independent-day sample is small. The original goal of100 background-day groups is not achievable in this source. Paired uncertainty is computed at recording-day level, with source-group sensitivity and an explicit five-day limitation; clip counts do not substitute for independent groups. AIS presence is not human-verified audibility. No real event boundaries or object range/bearing labels are invented.

Native audio has three valid hydrophone channels in a four-channel file, with the unused channel excluded. Select hydrophone channel0 before a GPU anti-aliased32kHz→16kHz derivative. The primary unit is the native three-second recording, with one recording-level candidate for presence verification. Controlled longer scenes separately evaluate temporal event activity; the manuscript must not imply real temporal localization or individual resolution of overlapping objects.

All acquisition receipts, conflicting-label IDs, split rules and hashes are preserved in data/manifests/. Downloaded original four-channel files remain unchanged. This source change is driven by accessibility and independent provenance, not performance.

## Representations

CUDA Fourier/STFT/wavelet numerical fixtures passed. The bounded piecewise-linear EMD implementation reconstructed inputs and recovered a pure tone, but approximately96–100% of modes in noisy fixtures reached the ten-sift/non-IMF limit. Therefore Fourier, STFT and wavelets are the primary validated representations. The bounded HHT approximation is retained only as an explicitly exploratory branch in the supplemental study; it is not represented as converged classical EMD. See manifests/dsp_validation.json and protocol/numerical_amendment.md.

## Feasible model sizes and interventions

The initial32-channel flow U-Net has1,997,121 parameters. It completed a64-step training/replacement smoke pilot within the GPU memory limit. The smaller model replaces the prospective10–30million-parameter estimate; model size is not a novelty claim. The pilot is a functionality check, not evidence of detection benefit.

Primary real verification uses a whole-recording candidate, so no fabricated within-recording real labels are needed. The class-free generator is trained with both partial and full masks; whole-recording generation uses no target class or label. Supplementary controlled event tests use masks or proposed intervals whose label provenance is stated separately. A generated replacement may remove all sources in its support, so source-selective claims remain unsupported unless preservation controls demonstrate them.

The same-support nuisance edit uses a background-noise phase with a spectrum shaped to the actual replacement perturbation, then the identical support/taper and RMS matching. Its exact target preservation and spectral mismatch are evaluated on controlled stems. A nuisance edit can still obscure a source; it is a confound control, not a physically identified counterfactual.

## Checkpointing and frozen evaluation

The project-local environment is locked in requirements-research.lock. All substantial tensors execute on the UUID-pinned RTX5000 Ada. CPU decoding, tokenization, serialization, statistical summaries and plotting are incidental host work.

Checkpoint storage preserves model, optimizer, scheduler/scaler when used, random states, next-batch cursor, configuration, data/code fingerprints and two integrity-checked generations. A separate-process CUDA test reproduced the next optimizer step exactly and recovered from a damaged latest checkpoint using the prior generation. Validation artifacts are in manifests/cuda_resume_validation.json.

Development may choose hyperparameters and numerical validity thresholds. Calibration fits score mappings and operating thresholds. Freeze configurations, weights, splits, prompts, baseline selection and statistical endpoints before producing final test predictions. Stages are marked complete only after their outputs are durable and checksummed; a resumed run validates existing artifacts and recomputes unfinished shards.
