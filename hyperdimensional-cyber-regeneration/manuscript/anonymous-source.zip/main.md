# Toward Vector-Symbolic and Neurosymbolic Cyber Planning under Adversarial Uncertainty

## Abstract

Cyber planners need useful evidence even when network measurements are incomplete or manipulated. Learning how to combine these measurements is a step toward regenerating evidence for vector-symbolic and neurosymbolic decision support. We study two extensions of masked graph autoencoding, which learns by reconstructing deliberately hidden measurements. The first gives greater weight to connections between network flows when their available measurements overlap and agree. The second encourages similar internal representations and predictions when different measurements are hidden. We evaluate these methods on selected labeled flows from the public CTU-13 botnet dataset, using graphs that connect flows sharing an endpoint and separating captures chronologically. Experiments compare graph models, associative representations, contextual predictors, and inexpensive statistical and neural baselines under recorded measurements, controlled missingness, and feature replacement. Matched controls help identify which changes contribute, while GPU measurements establish their computing costs. Exploratory results show promising improvements in identifying botnet traffic and estimating its probability, together with greater tolerance of missing measurements. Consistency training improves the reference model's observed mean performance while keeping the same prediction architecture. The comparisons clarify when weighting connections and learning to reconstruct measurements are useful. These findings provide practical guidance for learning from incomplete cyber evidence and a foundation for future integration with vector-symbolic and neurosymbolic planning.

**Keywords:** graph learning; masked autoencoders; missing data; consistency regularization; network-flow classification; cyber decision support.

## 1. Introduction

Cyber planners need to decide what to trust before deciding what to do. Consider a hypothetical defender choosing whether to isolate a host or collect more evidence. Some traffic measurements are missing, while others have been altered. Flows that share an endpoint provide useful context, but they may describe different activities. Combining all neighboring observations equally could therefore obscure the evidence needed for that decision.

This paper studies the learning problem beneath that scenario: how to represent network traffic when measurements are incomplete or misleading. Our experiments classify completed network flows; they do not test the isolation decision itself. Earlier synthetic studies examined repairing beliefs and scoring candidate actions. They showed that more complex or logically consistent representations did not automatically improve decisions; the supplement reports those results separately (Figures S1–S2).

We test two task-specific extensions of a GraphMAE-adapted classifier [1], which learns by reconstructing hidden measurements. EDGE_GMAE weights connections using the overlap and agreement of available measurements. CONS_GMAE encourages similar representations and predictions when additional measurements are hidden. Simpler models and matched controls help identify which changes contribute, while GPU measurements establish their computing costs. Observed gains remain exploratory because earlier test results motivated this follow-up.

## 2. Related Work

GraphMAE learns to reconstruct hidden node measurements and also masks internal representations before decoding [1]. Our comparator follows these mechanisms, using mean squared error (MSE) on observed measurements instead of the original scaled cosine error. It is therefore an adaptation. GraphMAE2 already combines multiple reconstruction views with prediction of internal representations [2]; consistency in masked graph learning is established in principle.

Earlier methods also seek to make graph learning more robust. Pro-GNN learns graph structure alongside predictions [3], while structure-aware DropEdge uses node features to sample edges [4]. Other work selects measurements to mask by estimated reliability and separates reconstruction tasks [5]. Recent findings emphasize consistent neighborhood information and the value of connections between dissimilar nodes [6]. Similarity alone therefore need not identify useful evidence. Our contribution is a fixed weighting rule that excludes unavailable measurements, prevents hidden reconstruction targets from affecting weights, and is tested on network traffic. These additional literature methods establish context; they are not experimental baselines here.

## 3. Observation-Aware Graph Learning

### 3.1. Representation and comparator

Each chronological window contains up to 32 retained flows. Connections join flows sharing any observed source or destination endpoint, allowing the model to use related traffic as context. Each flow has fourteen processed measurements and fourteen flags indicating which are available. The GMAE comparator uses a width-128, three-layer residual encoder with self/neighbor transformations, layer normalization, and GELU activations. Its output is the probability of the botnet label.

During five pretraining epochs, 30% of valid nodes are independently masked and their inputs replaced with a learned token. The model also masks their internal representations before a decoder reconstructs measurements using neighboring nodes. Reconstruction MSE covers only originally observed measurements of these additionally masked, non-padding nodes.

Supervised training averages binary cross-entropy plus Brier loss over valid flows in each window. Weighting each capture inversely by its number of windows gives captures equal expected contribution. DENSE uses the same architecture without masked pretraining. Parameter counts include the decoder, which is inactive during classification.

### 3.2. Visible-evidence aggregation

For illustration, suppose two flows share a server but one lacks a byte count. The weighting rule compares only measurements available in both flows, reducing the influence of links with little shared evidence.

Let \(x_i\in\mathbb R^{14}\) be a normalized measurement vector, \(m_i\in\{0,1\}^{14}\) its current visibility indicators, \(A\) the supplied endpoint adjacency, and \(V\) the valid nodes of one window. Define shared support and discrepancy:

\[
s_{ij}=\sum_{k=1}^{14}m_{ik}m_{jk},\qquad
r_{ij}=s_{ij}/14,\qquad
d_{ij}=\frac{\sum_k m_{ik}m_{jk}(x_{ik}-x_{jk})^2}{\max(1,s_{ij})}.
\tag{1}
\]

Our experimental aggregation rule is

\[
\bar A_{ij}=
\begin{cases}
1,&i=j,\ i\in V,\\
A_{ij}[0.1+0.9r_{ij}\exp(-d_{ij}/2)],&i\ne j,\ i,j\in V,\\
0,&\text{otherwise},
\end{cases}
\qquad
P_{ij}=\frac{\bar A_{ij}}{\max(1,\sum_\ell\bar A_{i\ell})}.
\tag{2}
\]

EDGE_GMAE uses \(P\) to weight connections in the same encoder and decoder. A minimum weight retains weak neighbor information even without shared measurements; each node retains a self weight of one before normalization. The rule adds no learned parameters. Pretraining computes weights after masking inputs and clearing their availability flags, so hidden reconstruction targets cannot affect connection weights.

EDGE_DENSE uses these weights without masked pretraining. Comparing EDGE_GMAE with GMAE tests weighting under the same training objective; EDGE_DENSE versus DENSE tests it without pretraining; EDGE_GMAE versus EDGE_DENSE tests pretraining under the same weighting rule. Equation (2) measures agreement, not truth: coordinated false values may agree, while useful but different neighbors may receive less weight.

### 3.3. Reconstruction and prediction consistency

Consistency training encourages a model to give similar answers when some input details change, an established idea in semi-supervised learning [7]. Here, the change is hiding additional measurements.

CONS_GMAE uses the same prediction architecture as GMAE. During pretraining, two independently sampled 30% node masks produce internal representations \(h^{(1)}\) and \(h^{(2)}\) and reconstruction losses \(L_{\mathrm{rec}}^{(1)},L_{\mathrm{rec}}^{(2)}\). The stop-gradient operator \(\operatorname{sg}\) holds a target fixed while updating the other view:

\[
C=\frac{1}{2|V|}\sum_{i\in V}
\left[1-\cos(h_i^{(1)},\operatorname{sg}(h_i^{(2)}))
+1-\cos(h_i^{(2)},\operatorname{sg}(h_i^{(1)}))\right],
\qquad
L_{\mathrm{pre}}=\tfrac12(L_{\mathrm{rec}}^{(1)}+L_{\mathrm{rec}}^{(2)})+0.5C.
\tag{3}
\]

The consistency term compares valid nodes only. Both views use the same current model, without a separate teacher, moving-average target, extra projection layer, or inaccessible clean measurements.

For example, a flow might be viewed once with its duration visible and once with it hidden. Supervised consistency encourages similar predictions. Training hides 20% of currently observed coordinates, clearing values and flags to obtain \(\tilde x\). For \(p=f_\theta(x,A)\) and \(\tilde p=f_\theta(\tilde x,A)\),

\[
L_{\mathrm{sup}}=L_{\mathrm{BCE+Brier}}(p,y)
+\frac{0.5}{|V|}\sum_{i\in V}(\tilde p_i-\operatorname{sg}(p_i))^2.
\tag{4}
\]

The supplied observation may already be corrupted, so matching its prediction does not guarantee correctness. CONS_PRE uses Equation (3) without the extra term in Equation (4), isolating supervised consistency. Comparing CONS_PRE with GMAE changes both the number of views and their alignment; a control using two views without alignment is still needed to separate those effects.

## 4. Experimental Design

### 4.1. Recorded data and artificial corruption

CTU-13 contains 2011 university traffic recorded during controlled executions of real botnets [8]. Across all thirteen bidirectional-flow tables, we retain author labels From-Normal and From-Botnet: 799,777 of 19,976,700 rows (4.00%). Background and other uncertain labels are excluded rather than assumed benign. Filtering precedes window and graph construction.

Captures 1–8 and 13 provide 442,084 training flows; capture 9 provides 214,880 validation flows; captures 10–12 provide 142,813 test flows. All training flows finish before validation starts, and validation finishes before testing starts, checked using completion times rather than capture identifiers. Hosts may recur, so separation is temporal and by capture, not by host. Test captures 10–11 contain Rbot; capture 12 contains NSIS.ay, absent from training. Pooled botnet-label prevalences are 0.324, 0.861, and 0.817 for training, validation, and test, respectively.

Features are log-duration, log-packet count, log-bytes, log-source bytes, source-byte fraction, log-bytes per packet, normalized source/destination ports, TCP/UDP/ICMP indicators, and S/F/R state indicators. Log transforms use \(\log(1+x)\). The first six coordinates use training-only observed-coordinate standardization and clipping to \([-5,5]\); invalid coordinates are zeroed and flagged unavailable. IP addresses define adjacency but are not numeric features. Absolute timestamps and capture identifiers are excluded. Nonoverlapping windows follow start time and row order, with padded final windows masked.

Missing20/50 independently hide 20%/50% of observed feature coordinates. Spoof20/40 independently replace 20%/40% of the first eight observed numeric coordinates with training verified-normal means while retaining visibility flags. Replacement preserves categorical flags; both stress families retain endpoint topology. These are artificial measurement stresses, not observed deception or packet-valid adaptive attacks. Training windows are assigned once, modulo three, to clean, Missing20, or Spoof20; validation uses all three conditions.

### 4.2. Comparators and optimization

Nine previously executed baselines are imported unchanged, with matched input and prediction fingerprints. Gaussian naive Bayes (NB; 58 fitted statistics) skips missing-coordinate likelihoods. LOGIT uses 29 parameters. Our denoising autoencoder (DAE) [9] uses a \(28\to32\to8\) encoder, \(8\to32\to14\) decoder, and supervised readout: 1,951 parameters, five denoising epochs, 25% additional feature masking, and retained-coordinate Gaussian noise. HDC appends vector-symbolic associative retrieval features [10] from a fixed 4,096-dimensional bipolar codebook to the graph model, giving 125,227 parameters. This does not measure network compression.

SCR_FLOW uses window means and standard deviations of learned per-flow embeddings as context and a four-expert probability mixture (10,664 parameters); CTX_FLOW uses a single contextual expert and LOCAL_FLOW zeroes that context (8,257 parameters each). These controls distinguish contextual aggregation from graph reconstruction and inexpensive local learning.

All four new graph variants retain GMAE's 121,643 parameters. Seeds are 11, 23, 37, 51, and 71; optimization uses AdamW [11], learning rate 0.001, weight decay \(10^{-4}\), batches of 256 windows, at most 40 supervised epochs, and patience eight. Checkpoints minimize the same validation BCE-plus-Brier objective, excluding method-specific regularizers. Clean-validation attack-F1 thresholds are frozen across test conditions. All twenty new fits and thresholds were completed before new test inference. However, earlier test results motivated these variants, making this an exploratory reused-test study.

Training and inference ran on an NVIDIA RTX 5000 Ada Generation GPU, with PyTorch 2.9.1/CUDA 12.8, BF16 training autocast, and FP32 inference with TF32 permitted. CPU work handled parsing, statistics, and rendering. Equal parameters and epoch caps do not imply equal computation: CONS adds training passes and EDGE adds pairwise comparisons. NB repeats the same deterministic fit in five seed slots.

### 4.3. Estimands and uncertainty

The primary measure is attack average precision (AP), which rewards placing botnet flows near the top of a ranked list. We average three fixed test captures equally within each seed, then average seeds. Two specified contrasts compare EDGE_GMAE and CONS_GMAE with GMAE. We use 1,000 shared paired bootstrap draws crossing seed resampling with contiguous 64-window blocks within each capture, recomputing exact tie-aware AP. Captures 10/11/12 contain 60/6/5 blocks; no draw lacked positive labels.

We report 95% and 97.5% marginal percentile intervals; the latter target nominal 95% family coverage for two comparisons under the bootstrap approximation. Captures are fixed, not population-resampled. Small block populations, temporal dependence, and adaptive reuse limit interpretation; multiplicity adjustment does not restore an untouched test. Other comparisons and seed-t intervals are descriptive. ROC-AUC, Brier score, recall, false-positive rate (FPR), and resource measurements complement AP. Brier score measures probability error; lower is better. Calibration asks whether predicted probabilities match observed botnet frequencies [12].

## 5. Results

### 5.1. Clean discrimination and calibration

Table 1 reports all thirteen methods. EDGE_GMAE increases mean AP by 0.01580 relative to GMAE. Its 95% interval is [0.00097, 0.03710], but its 97.5% interval is [-0.00036, 0.04321]. CONS_GMAE increases mean AP by 0.00518, with corresponding intervals [-0.00184, 0.01441] and [-0.00257, 0.01639]. Neither adjusted interval excludes zero; neither superiority nor equivalence is established (Figure 1).

Table 1. Clean capture-macro means over five seed slots. AP and AUC are higher-better; Brier and FPR are lower-better. Thresholds are selected on clean validation. Rankings are descriptive.

| Method | AP | ROC-AUC | Brier | Recall | FPR |
|---|---:|---:|---:|---:|---:|
| NB | 0.91784 | 0.85354 | 0.07667 | 0.95910 | 0.29085 |
| LOGIT | 0.63538 | 0.49517 | 0.30425 | 0.94267 | 0.99370 |
| DAE | 0.86743 | 0.75879 | 0.08797 | 0.86692 | 0.28788 |
| DENSE | 0.98151 | 0.98084 | 0.04634 | 0.81632 | 0.07115 |
| GMAE | 0.97830 | 0.97753 | 0.05973 | 0.81815 | 0.07330 |
| HDC | 0.97578 | 0.97603 | 0.04873 | 0.81210 | 0.06840 |
| SCR_FLOW | 0.96616 | 0.97284 | 0.06672 | 0.80520 | 0.09828 |
| CTX_FLOW | 0.95602 | 0.94072 | 0.07728 | 0.82071 | 0.20422 |
| LOCAL_FLOW | 0.84756 | 0.73533 | 0.09652 | 0.79046 | 0.28721 |
| EDGE_GMAE | 0.99411 | 0.99566 | 0.04262 | 0.81600 | 0.04265 |
| EDGE_DENSE | 0.99500 | 0.99569 | 0.04222 | 0.80805 | 0.04621 |
| CONS_GMAE | 0.98348 | 0.98391 | 0.04661 | 0.81717 | 0.06632 |
| CONS_PRE | 0.98272 | 0.98357 | 0.04715 | 0.82896 | 0.07251 |

[FIGURE1]

Figure 1. Clean performance and uncertainty. (A) Thirteen-method capture-macro AP with descriptive 95% seed-t intervals. (B) Paired seed/time-block 95% and 97.5% intervals for the two specified contrasts. Both wider intervals cross zero; descriptive rankings do not establish superiority. Figure labels abbreviate EDGE_GMAE, EDGE_DENSE, CONS_GMAE and CONS_PRE as EDGE, EDGE-0, CONS and CONS-P; SCR, CTX and LOCAL omit the _FLOW suffix.

EDGE_DENSE achieves the highest mean AP, 0.99500, without pretraining. GMAE also has a lower observed mean than DENSE. Both weighted models improve on GMAE's observed clean mean, including the model trained without pretraining. EDGE_GMAE's AP improvements are 0.00079, 0.04242, and 0.00420 across captures; the largest occurs in capture 11. Capture conditions and malware family vary together, so this pattern cannot explain which caused the difference.

Figure 2 shows rankings within captures and calibration across pooled predictions. EDGE_GMAE reduces Brier score from 0.05973 to 0.04262 and FPR from 0.07330 to 0.04265, while recall remains similar (0.81815 versus 0.81600). This means lower average probability error and a lower false-alarm rate at the selected thresholds. Botnet prevalence changes across splits, making fixed thresholds consequential: LOGIT's FPR approaches one. Inexpensive NB exceeds DAE in AP, and CTX_FLOW exceeds LOCAL_FLOW, supporting careful comparisons before adding complexity.

[FIGURE2]

Figure 2. Capture-specific discrimination and pooled calibration. (A) Clean AP for GMAE, DENSE, HDC, DAE, EDGE_GMAE, and CONS_GMAE, showing variation across fixed test captures. (B) Clean reliability bins pooled by flow support across captures and seeds. Repeated predictions share flows and are not independent observations.

### 5.2. Stress and matched controls

At 50% missingness, AP is 0.93553 for GMAE, 0.95962 for EDGE_GMAE, 0.95360 for EDGE_DENSE, and 0.95249 for CONS_GMAE. At 40% numeric replacement, values are 0.96716, 0.98535, 0.98432, and 0.97781, respectively (Figure 3). Pretraining helps the weighted model under severe missingness in these comparisons, although it offers no clean advantage.

CONS_GMAE's clean gain over CONS_PRE is only 0.00076; CONS_PRE is slightly better under both missingness levels. Training for stable predictions adds no consistent observed benefit beyond pretraining. These fixed feature tests do not simulate an adversary adapting to the model.

[FIGURE3]

Figure 3. Artificial corruption and matched controls. (A) Capture-macro AP for six graph methods across five conditions. (B) Three pretraining/consistency contrasts, with descriptive seed-t intervals; CONS_PRE versus GMAE jointly changes view count and alignment. Missing and replacement conditions alter features while retaining endpoint topology.

### 5.3. Resource costs and verification

A common-session timing audit uses the same prepared 32-flow window for all thirteen inference architectures. Median bounded host-to-GPU-to-host latency is 2.374 ms for GMAE, 2.929 ms for EDGE_GMAE, and 2.381 ms for CONS_GMAE; corresponding p95 values are 2.805, 3.714, and 2.839 ms. EDGE's weighting rule adds no learned parameters but requires extra comparisons, doubling additional peak memory from 0.093 to 0.187 MiB. CONS preserves inference architecture but increases mean training time from the historical GMAE measurement of 24.148 s to 29.994 s. Early stopping and separate training sessions mean these timings do not compare identical amounts of computation.

Timing includes decoded-input transfer, normalization, endpoint graph construction, inference, and prediction return. It excludes flow extraction, waiting for completion/windows, cold loading, and network transit. Incremental memory excludes resident model/data allocations. These are bounded processing costs, not complete detection latency or communication compression (Figure 4).

[FIGURE4]

Figure 4. Measured computational tradeoffs. (A) Actual supervised and pretraining times for six graph methods; baseline training measurements are imported. (B) Common-session wall latency versus AP for eight methods, with p10–p95 repeat quantiles horizontally. Timing quantiles describe repeated measurements, not confidence intervals. Unequal forward passes and early stopping affect training cost.

Audits checked 975 summary records, 6,825 recomputed metrics, and 65 checkpoint hashes. Seventy-five replay cases for GMAE and the four new methods reproduced probabilities, AP, and Brier exactly. Training trajectories and seed effects appear in Figures S3–S4. These checks confirm that saved results can be reproduced; performance on new traffic still requires testing.

## 6. Limitations and Scope

Selected labels, recurring hosts, and reused historical test captures limit evidence about new settings; reserved contemporary traffic from independent organizations would help improve transfer to new networks.

Existing controls do not fully separate reconstruction from consistency; training on two masked views without aligning them would clarify which steps help and could simplify training.

Completed-flow classification leaves planning untested; sequential cyber testbeds would show how improved evidence affects action choices, replanning, and communication costs.

## 7. Conclusion

We tested two task-specific extensions of masked graph learning: weighting connections by shared, agreeing measurements, and encouraging stable representations and predictions when measurements disappear. Weighted models achieved the highest observed mean average precision across tested conditions. Consistency training also improved the reference model's mean performance without changing its prediction architecture. Matched controls show when learning to reconstruct hidden measurements helps, with an advantage under severe missingness. These exploratory findings identify practical ways to combine incomplete evidence and quantify their computing costs. Future vector-symbolic and neurosymbolic planners could use these insights to build evidence for comparing actions and replanning.

## References

[1] Z. Hou, X. Liu, Y. Cen, Y. Dong, H. Yang, C. Wang, and J. Tang, “GraphMAE: Self-Supervised Masked Graph Autoencoders,” in Proc. ACM SIGKDD, 2022. https://arxiv.org/abs/2205.10803.

[2] Z. Hou, Y. He, Y. Cen, X. Liu, Y. Dong, E. Kharlamov, and J. Tang, “GraphMAE2: A Decoding-Enhanced Masked Self-Supervised Graph Learner,” in Proc. ACM Web Conference, 2023. https://arxiv.org/abs/2304.04779.

[3] W. Jin, Y. Ma, X. Liu, X. Tang, S. Wang, and J. Tang, “Graph Structure Learning for Robust Graph Neural Networks,” in Proc. ACM SIGKDD, 2020. https://arxiv.org/abs/2005.10203.

[4] J. Han, W. Huang, Y. Rong, T. Xu, F. Sun, and J. Huang, “Structure-Aware DropEdge Towards Deep Graph Convolutional Networks,” IEEE Transactions on Neural Networks and Learning Systems, early access, 2023, doi:10.1109/TNNLS.2023.3288484.

[5] S. Song, P. Li, M. Dun, Y. Zhang, H. Cao, and X. Ye, “Equipping Graph Autoencoders: Revisiting Masking Strategies from a Robustness Perspective,” in Proc. SIAM International Conference on Data Mining, 2025, pp. 366–375, doi:10.1137/1.9781611978520.39.

[6] G. Tang, K. Liu, X. Yang, and Y. Qian, “Reconstruction Outcomes Look Similar but Processes Differ: Improving Context Consistency and Coverage in Graph Masked Auto-Encoder,” in Proc. ICML, PMLR, vol. 306, 2026, pp. 118954–118971. https://proceedings.mlr.press/v306/tang26l.html.

[7] S. Laine and T. Aila, “Temporal Ensembling for Semi-Supervised Learning,” in Proc. International Conference on Learning Representations, 2017. https://arxiv.org/abs/1610.02242.

[8] S. García, M. Grill, J. Stiborek, and A. Zunino, “An empirical comparison of botnet detection methods,” Computers & Security, vol. 45, pp. 100–123, 2014, doi:10.1016/j.cose.2014.05.011. Dataset: https://www.stratosphereips.org/datasets-ctu13.

[9] P. Vincent, H. Larochelle, Y. Bengio, and P.-A. Manzagol, “Extracting and Composing Robust Features with Denoising Autoencoders,” in Proc. International Conference on Machine Learning, 2008, pp. 1096–1103, doi:10.1145/1390156.1390294.

[10] D. Kleyko, D. A. Rachkovskij, E. Osipov, and A. Rahimi, “A Survey on Hyperdimensional Computing aka Vector Symbolic Architectures, Part I: Models and Data Transformations,” ACM Computing Surveys, vol. 55, no. 6, pp. 1–40, 2022, doi:10.1145/3538531.

[11] I. Loshchilov and F. Hutter, “Decoupled Weight Decay Regularization,” in Proc. International Conference on Learning Representations, 2019. https://arxiv.org/abs/1711.05101.

[12] C. Guo, G. Pleiss, Y. Sun, and K. Q. Weinberger, “On Calibration of Modern Neural Networks,” in Proc. International Conference on Machine Learning, PMLR, vol. 70, 2017, pp. 1321–1330. https://proceedings.mlr.press/v70/guo17a.html.
